package org.example;

import okhttp3.OkHttp;
import org.example.models.SimpleModel;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Controller
public class Main {
    static {
        // Some usage of random libs to test project classpath import
        OkHttp okHttp = OkHttp.INSTANCE;
    }

    @MessageMapping("fire.and.forget1")
    public Mono<Void> fireAndForget1(@RequestBody SimpleModel model) {
        return Mono.empty();
    }

    @MessageMapping("fire.and.forget2")
    public void fireAndForget2(@RequestBody SimpleModel model) {

    }

    @MessageMapping("request.response1")
    public Mono<SimpleModel> requestResponse1(@RequestBody SimpleModel model) {
        return Mono.empty();
    }

    @MessageMapping("request.response2")
    public SimpleModel requestResponse2(@RequestBody SimpleModel model) {
        return null;
    }

    @MessageMapping("request.stream")
    public Flux<SimpleModel> requestStream(@RequestBody SimpleModel model) {
        return Flux.empty();
    }
}