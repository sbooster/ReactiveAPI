package org.example.models;

public record SimpleModel(
        byte somePByte,
        int somePInt,
        long somePLong,
        float somePFloat,
        double somePDouble,
        String someString
) {
}
