plugins {
    id("java")
    id("dev.socialbooster.gradle.reactiveapi") version "1.5.0-SNAPSHOT"
}

group = "org.example"

repositories {
    mavenLocal()
    mavenCentral()
}

dependencies {
    implementation("com.squareup.okhttp3:okhttp:4.10.0")
    implementation("org.springframework.boot:spring-boot-starter-rsocket:2.7.6")
}

tasks {
    generateReactiveAPI {
        prettyPrint = true
    }
}
