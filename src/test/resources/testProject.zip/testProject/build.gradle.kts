plugins {
    id("java")
    id("dev.socialbooster.gradle.reactiveapi") version "1.2.3-SNAPSHOT"
}

group = "org.example"

repositories {
    mavenLocal()
    mavenCentral()
}

dependencies {
    implementation("com.squareup.okhttp3:okhttp:4.10.0")
    implementation("org.springframework.boot:spring-boot-starter-rsocket:2.7.6")
    implementation("dev.socialbooster.gradle:reactiveapi:1.2.3-SNAPSHOT")
//    compileOnly("dev.socialbooster.gradle:reactiveapi:1.2.3-SNAPSHOT")
//    annotationProcessor("dev.socialbooster.gradle:reactiveapi:1.2.3-SNAPSHOT")
}

tasks {
    generateReactiveAPI {
        prettyPrint = true
    }
}
