dependencyResolutionManagement {
    pluginManagement {
        repositories {
            mavenCentral()
            mavenLocal()
            gradlePluginPortal()
        }
    }
}