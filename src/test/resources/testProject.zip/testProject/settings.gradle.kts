dependencyResolutionManagement {
    pluginManagement {
        repositories {
            mavenCentral()
            mavenLocal()
        }
    }
}