package org.example;

import dev.socialbooster.gradle.reactiveapi.annotations.Schema;
import dev.socialbooster.gradle.reactiveapi.annotations.Tags;
import jdk.jfr.Description;
import okhttp3.OkHttp;
import org.example.models.ImportantModel;
import org.example.models.SimpleModel;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.Map;

@Controller
@Schema(description = "description for Main.class")
public class Main {
    static {
        // Some usage of random libs to test project classpath import
        OkHttp okHttp = OkHttp.INSTANCE;
    }

    @MessageMapping("fire.and.forget1")
    @Schema(description = "first description")
    @Description("some description")
    public Mono<Void> fireAndForget1(@RequestBody SimpleModel model) {
        return Mono.empty();
    }

    @MessageMapping("fire.and.forget2")
    @Tags(tags = {"#LegendOfZelda", "#StrangeThinks", "#MortalKombat"})
    public void fireAndForget2(@RequestBody SimpleModel model) {
    }

    @MessageMapping("fire.and.forget3")
    @Schema(description = "third description")
    @Description("some description")
    public void fireAndForget3(@RequestBody Map<String, SimpleModel> model) {
    }

    @MessageMapping("request.response1")
    public Mono<SimpleModel> requestResponse1(@RequestBody SimpleModel model) {
        return Mono.empty();
    }

    @MessageMapping("request.response2")
    @Tags(tags = {"#someTag1", "#someTag2"})
    public SimpleModel requestResponse2(@RequestBody SimpleModel model) {
        return null;
    }

    @MessageMapping("request.response3")
    public Mono<Map<String, SimpleModel>> requestResponse3(@RequestBody SimpleModel model) {
        return Mono.empty();
    }

    @MessageMapping("request.response4")
    public Map<String, SimpleModel> requestResponse4(@RequestBody List<SimpleModel> model) {
        return null;
    }

    @MessageMapping("request.stream1")
    public Flux<SimpleModel> requestStream1(@RequestBody SimpleModel model) {
        return Flux.empty();
    }

    @MessageMapping("request.stream1")
    public Flux<ImportantModel> customRequestStream1(@RequestBody SimpleModel model) {
        return Flux.empty();
    }

    @MessageMapping("request.stream2")
    public Flux<Map<String, SimpleModel>> requestStream2(@RequestBody SimpleModel model) {
        return Flux.empty();
    }

    @MessageMapping("primitive.request1")
    public Flux<Map<String, SimpleModel>> primitiveArgRequest1(String name) {
        return Flux.empty();
    }

    @MessageMapping("primitive.request2")
    public Flux<Map<String, ImportantModel>> primitiveArgRequest2(int age) {
        return Flux.empty();
    }
}
