package org.example.models;

import dev.socialbooster.gradle.reactiveapi.annotations.Schema;
import dev.socialbooster.gradle.reactiveapi.annotations.Tags;

import java.util.Map;

@Schema(description = "this is an important model for a test case")
@Tags(tags = {"youtube", "TV", "walk", "PS4", "DnD"})
public record ImportantModel(
        byte somePByte,
        @Schema(description = "very important field")
        int somePInt,
        long somePLong,
        @Schema(description = "to delete. Only for a test")
        float somePFloat,
        double somePDouble,
        Byte someByte,
        Integer someInt,
        Long someLong,
        Float someFloat,
        Double someDouble,
        String someString,
        SimpleModel someModel,
        Map<String, SimpleModel> someMap
) {
}
