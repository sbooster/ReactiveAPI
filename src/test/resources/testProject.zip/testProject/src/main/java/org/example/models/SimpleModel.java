package org.example.models;

import java.util.Map;

public record SimpleModel(
        byte somePByte,
        int somePInt,
        long somePLong,
        float somePFloat,
        double somePDouble,
        Byte someByte,
        Integer someInt,
        Long someLong,
        Float someFloat,
        Double someDouble,
        String someString,
        SimpleModel someModel,
        Map<String, SimpleModel> someMap
) {
}

